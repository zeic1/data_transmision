var app = new Vue({
    el: '#app',
    data: function() {
        return {
            users: [],
            usersService: null,
            currentUser: {
                id: null,
                name: '',
                city: ''
            },
            editing: false
        };
    },
    created: function () {
        this.usersService = users();
        this.loadUsers();
    },
    methods: {
        loadUsers: function() {
            this.usersService.get()
                .then(response => {
                    this.users = response.data;
                })
                .catch(error => {
                    console.error('Error loading users:', error);
                });
        },
        
        saveUser: function() {
            if (this.editing) {
                // Update existing user
                this.usersService.put(this.currentUser)
                    .then(() => {
                        this.loadUsers();
                        this.resetForm();
                    })
                    .catch(error => {
                        console.error('Error updating user:', error);
                    });
            } else {
                // Add new user
                this.usersService.post(this.currentUser)
                    .then(() => {
                        this.loadUsers();
                        this.resetForm();
                    })
                    .catch(error => {
                        console.error('Error adding user:', error);
                    });
            }
        },
        
        editUser: function(user) {
            this.currentUser = Object.assign({}, user);
            this.currentUser.id = this.users.indexOf(user);
            this.editing = true;
        },
        
        deleteUser: function(userId) {
            this.usersService.delete(userId)
                .then(() => {
                    this.loadUsers();
                })
                .catch(error => {
                    console.error('Error deleting user:', error);
                });
        },
        
        cancelEdit: function() {
            this.resetForm();
        },
        
        resetForm: function() {
            this.currentUser = {
                id: null,
                name: '',
                city: ''
            };
            this.editing = false;
        }
    }
})